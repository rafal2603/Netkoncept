<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'kebabjunior');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'DI,2~_zT99*|7utdLn2mD9Fd]+P;Oi_ZU{x-4i!?V}8z#_7GF+BcMye0BBdOizLL');
define('SECURE_AUTH_KEY',  'U2a37hm=m7]3e 7phbv&Yc=a[MzWc|lx30Yjg3ubI&0$}0x#oX.u&fr}/2v[qW`Q');
define('LOGGED_IN_KEY',    '-Zdz5M]6Twu!+wlY`uL?[SArD^xAlmwu6mDGR(02pGGN(UO6:I^X,U9cIXbI9Lx&');
define('NONCE_KEY',        '0:Pm480=/0NG{fD%CXx9:4Ndx,6zbqt*YrxE[!:SWR#17oDRm5o*(#EB5A|g5Uy<');
define('AUTH_SALT',        'C`-4u%f*E!u#0YicQRZm+FeellR[rf7a*%$sTUv2^:EzRvh)FejHt8{]~e/[QWm6');
define('SECURE_AUTH_SALT', 'i%5&oyWP#;Ajt&dti:0X4BSM&B@!zu>r,/%^~:5:B7+dU/a0Z9Vdi$KAlV!U2Z<L');
define('LOGGED_IN_SALT',   'o>hRRKPP;z&H<V?49;&wDRo fb 50fis_w3UNaGo4z6/Zsyx5Go90Y61;WYUr~WA');
define('NONCE_SALT',       'IR+2.-wq%@sd*`0zjL@3*/)Oz^|I|[_I:muwW!1su{.O}sx(MWY*vN?bYkF84x<h');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
